<?php 
return[
'404'	=>	'Error 404',
'pagenotfound'	=>	'Page Not Found',
'content1'	=>	'We have not found what you are looking for. ',
'content2'	=>	'We have put our robots to search.',
'btn'	=>	'Go Home',
];