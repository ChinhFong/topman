<?php
return[
	'cs'	=>	'Coming Soon',
	];