<?php 
return [
'pages'	=>	'Pages',
'aboutus'=>	'About Us',
'content'	=>	' was established in 2004. Within 13 years in the manpower recruitment service, Top Manpower is an excellent company in providing the sophisticated recruitment services for trainees to work in Japan, employees to work in Malaysia, Thailand, Singapore, Brunei, Hong Kong, Macau and Cambodian trainees in Japan, and workers to work in Cambodia in accordance with the Cambodian Labour Law.Top Manpower Co., Ltd is a private limited company, registered no Co.6664KH/2004 at the Ministry of Commerce. More importantly, Top Manpower Co., Ltd is licensed by the Ministry of Labor and Vocational Training to recruit, train, dispatch and manage Cambodian workers to work in Malaysia, Thailand, Singapore, Brunei, Hong Kong, Macau and Cambodian trainees in Japan.',
'content2'=>	'Our company is in recruitment service for the various industries such as the construction, SMEs, garment, production manufacture, transportation, warehouse, agriculture, foods, fishing, hospitality, tourism, domestic workers, and others. Our recruitment services are widely recognized by the employers in the receiving countries.',
'content3'=>	'It is our earnestly hopes that whenever you have a demand of manpower you may kindly turn towards Top Manpower and allow us to serve you with expeditious service with qualities, Effectiveness, decent prices, integrity and a difference.',
'otherinfo'	=>	'Other information',
'cgi2'	=>	'Top Manpower provides', //Collapsible Group Item #2
'cgi2.detail1'	=>	'A level of service to the hiring community and candidate marketplace that has earned us broad industry recognition and a long list of satisfied clients. We pledge to continue our commitment to matching the needs, goals and objectives of our clients and candidates to ensure long-term success.',
'cgi2.detail2'	=>	'It is earnestly hopped that when ever you have a demand of manpower you may kindly turn towards Top Manpower and allow us to serve you with integrity and a difference.',
'cgi2.detail3'	=>	'You can always expect a very professional and sincere service from our side.',
'cgi2.detail4'	=>	'Looking forward for a long term business relations.',
'country'	=>	'Amount of worker in oversea Country',
'thailand'	=>	'Thailand'	,
'malaysia'	=>	'Malaysia',
'japan'	=>	'Japan',
'singapore'	=>	'Singapore',
'oi'	=>	'Other Information',
'thai'	=>	'Thai',
'malay'	=>	'Malaysian',
'japanese'	=>	'Japanese',

];