<?php 
return [
'500'	=>	'Error 500',
'ise'	=>	'Internal Server Error',
'content1'	=>	'Something has gone wrong we are trying to fix it.  ',
'content2'	=>	'Meanwhile you can go back to the homepage',
'btn'	=>	'Go Home',
];