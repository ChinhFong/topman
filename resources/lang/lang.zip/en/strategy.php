<?php 
return [
'header'	=>	'Top Manpower has the core value and strategy as following:',
'sus.content'	=> 'Our operation is embedded with the sustainability principle. In order to maintain our sustainable service, we focus on the marketing, management, training, and human resource to ensure that our service delivery is effective and efficiency.',
'service.content'	=>	"We strive to upgrade our service in response to the customer feedback. Effectiveness and quality are the main priorities of company to offer to all clients.",
'sr.content'	=>	'We care about people and the role of work in their lives. Our company inherently respects people as individual. We trust them, support them, and enable them to achieve their aims in work and life. We help people to develop their careers through career planning, coaching and training.',
'detail'	=>	'Percentage of',
'worker'	=>	'Worker',
'trainee'	=>	'Trainee',
'maid'	=>	'Housemaid',
'other'	=>	'Other',
'ej'	=>	'each Jobs',

];