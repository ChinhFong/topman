<?php
return[
'tc'	=>	'Training Center',
'dw'	=>	'Domestic Worker',
'gw'	=>	'General Worker',
'tw'	=>	'Technical Intern Trainer',
'all'	=>	'All',
'sc'	=>	'Select Category',
];
