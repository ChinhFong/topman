<?php
return [
'rm1'	=>	'To become as one of the leading recruitment',
'content'	=>	'募集代理店は、カンボジアでももっとも広いネットワークを持って職業訓練実習生を豊富に集めて参ります。',
];
