<?php
return [
'pages'	=>	'Pages',
'aboutus'=>	'会社活動',
'content'	=>	'トップメンパワー有限会社は２００４年に立ち上げました。今年まで十二年を迎えました、我が社は諸外国へ職業技能実習生を職業として斡旋しております、カンボジア国職業訓練省のル―ルに従って職業訓練省の許可証を受け総合代理店Co.6664KH/2004職業訓練の認可：406　ប.ក/ប្រ.ក 407ប.ក/ប្រ.កと408　ប.ក/ប្រ',
'content2'=>	'としてカンボジアの技能実習生を教育し派遣している企業です、主に　マレーシア、タイ、ブルネイ・ダルサラーム国、マカオ、ホンコン、日本に　技能実習生を派遣しております。',
'content3'=>	'我が社はスムーズに技能実習生が職種出来るように教育　実習しトレーニングを積み重ねてサービス業、建設業、農林水産業、運輸業、介護、縫製業、色々な方面で活躍出来るよう努力し頑張っております。',
'otherinfo'	=>	'Other information',
'cgi2'	=>	'Top Manpower provides', //Collapsible Group Item #2
'cgi2.detail1'	=>	'A level of service to the hiring community and candidate marketplace that has earned us broad industry recognition and a long list of satisfied clients. We pledge to continue our commitment to matching the needs, goals and objectives of our clients and candidates to ensure long-term success.',
'cgi2.detail2'	=>	'It is earnestly hopped that when ever you have a demand of manpower you may kindly turn towards Top Manpower and allow us to serve you with integrity and a difference.',
'cgi2.detail3'	=>	'You can always expect a very professional and sincere service from our side.',
'cgi2.detail4'	=>	'Looking forward for a long term business relations.',
'country'	=>	'Amount of worker in oversea Country',
'thailand'	=>	'Thailand'	,
'malaysia'	=>	'Malaysia',
'japan'	=>	'Japan',
'singapore'	=>	'Singapore',
'oi'	=>	'Other Information',
'thai'	=>	'Thai',
'malay'	=>	'Malaysian',
'japanese'	=>	'Japanese',

];
