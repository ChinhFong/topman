<?php $__env->startSection('title'); ?>
<?php echo e(trans('app.contact')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="main-header">
    <div class="container">
        <h1 class="page-title">&nbsp;</h1>
        <ol class="breadcrumb pull-right localefont">
            <li><a href="#"><?php echo e(trans('app.pages')); ?></a></li>
            <li class="active"><?php echo e(trans('app.contact')); ?></li>
        </ol>
    </div>
</header>
<section>
           <div class="col-xs-12">

            <h1 class="right-line no-margin-top localefont" style="overflow: visible;" ><?php echo e(trans('app.contact')); ?></h1>
           </div>
</section>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3909.2776314428284!2d104.88323731435842!3d11.531930991811569!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31095059f617973b%3A0x13c0b91b204651bd!2sTOP+Manpower+Co.%2C+Ltd.!5e0!3m2!1sen!2skh!4v1482879536513" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
<div class="container">
    <div class="row localefont text-icon wow animated fadeInDown animation-delay-4 localefont" style="visibility: visible; animation-name: fadeInDown;">
        <div class="col-md-12">
            <h2 class="localefont"><?php echo e(trans('app.morequestion')); ?></h2>
        </div>
        <div class="col-md-8">
            <section>
                <?php echo Form::open(['action'=>'SendmailController@store','method'=>'POST','files'=>true]); ?>

                    <?php echo e(csrf_field()); ?>

                    <?php if(Session::has('message')): ?>
                        <h2 style="color: green"><i class="fa fa-star"></i><?php echo e(Session::get('message')); ?></h2>
                    <?php endif; ?>
                     <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                     
                    <div class="form-group">
                        <label for="InputName"><?php echo e(trans('app.name')); ?></label>
                        <input type="text" class="form-control" id="InputName" name="name" id='name' value="<?php echo e(old('name',$user->name)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="InputEmail1"><?php echo e(trans('management.email')); ?></label>
                        <input type="email" class="form-control" id="InputEmail1" name="email" id='email' value="<?php echo e(old('email',$user->email)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="InputMessage"><?php echo e(trans('app.message')); ?></label>
                        <textarea class="form-control" id="InputMessage" rows="8" name="content" id='content' value="<?php echo e(old('content')); ?>"></textarea>
                    </div>
                    <button type="submit" class="btn btn-ar btn-primary"><?php echo e(trans('app.send')); ?></button>
                    <div class="clearfix"></div>
                <?php echo Form::close(); ?>

            </section>
        </div>
        <div class="col-md-4">
            <section>
                <div class="panel panel-primary">
                    <div class="panel-heading localefont"><i class="fa fa-envelope-o"></i><?php echo e(trans('contact.additional')); ?></div>
                    <div class="panel-body">
                        <h4 class="localefont"><?php echo e(trans('app.contact')); ?></h4>
                        <h5 class="localefont"><?php echo e(trans('app.ho')); ?></h5>
                        <address>
                            <strong><?php echo e(trans('app.tmp')); ?></strong><br>
                            <?php echo e(trans('app.address1')); ?><br>
                            <?php echo e(trans('app.address2')); ?><br>
                            <abbr title="Phone"></abbr><?php echo e(trans('app.number')); ?><br>
                            <?php echo e(trans('management.email')); ?> <a href="mailto:<?php echo e(trans('app.tmp.email')); ?>"><?php echo e(trans('app.tmp.email')); ?></a>
                        </address>
                        <h5 class="localefont"><?php echo e(trans('app.cothai')); ?></h5>
                        <address>
                            <strong><?php echo e(trans('app.tmp')); ?></strong><br>
                            <?php echo e(trans('app.address3')); ?><br>
                            <?php echo e(trans('app.address4')); ?><br>
                            <abbr title="Phone"></abbr><?php echo e(trans('app.number2')); ?><br>
                            <?php echo e(trans('management.email')); ?> <a href="mailto:<?php echo e(trans('app.tmp.email')); ?>"><?php echo e(trans('app.tmp.email')); ?></a>
                        </address>
					</div>
					
                </div>
            </section>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>