<?php $__env->startSection('title'); ?>
<?php echo e(trans('app.home')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row">
    <div class="col-xs-12">
      <article class="post animated fadeInDown animation-delay-6 acticle-style">
        <div class="panel panel-default">
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-12">
                      <img src="img/aboutus-home.jpg" class="img-responsive imageborder" alt="Image">
                  </div>
                  <div class="col-md-12">
                    <p class="p-lg p-style"><strong><?php echo e(trans('app.tmp')); ?></strong> <?php echo e(trans('home.welcome.rm')); ?>  <a href="/profile" class=""><?php echo e(trans('home.rm')); ?> &raquo;</a></p>
                </div>
                </div>
              </div>
              
                  
            </div>
          </div>
          <div class="panel-footer">
              <div class="row">
              </div>
          </div>
          <div class="panel-body">
            <h3 class="post-title"><?php echo e(trans('home.message')); ?> <?php echo e(trans('home.message.md')); ?></h3>
            <div class="row">
              <div class="col-md-8">
                <div class="row">
                   <div class="col-md-5">
                    <img src="img/management/b_bath_home.jpg" class="imageborder img-responsive">
                </div>
                <div class="col-md-7">
                    <p style="font-size:16px"><?php echo e(trans('home.message.dear')); ?></p>
                    <p class="just-style"><?php echo e(trans('app.tmp')); ?> <?php echo e(trans('home.message.topic')); ?></p>
                </div>
                <div class="col-md-12 just-style">
                    <p><?php echo e(trans('home.message.body')); ?> <b> <?php echo e(trans('home.message.body.important')); ?></b></p>
                    <p class="md-style-home"><?php echo e(trans('home.message.regard1')); ?></p>
                    <p class="md-style-home"><?php echo e(trans('home.message.md.name')); ?></p>
                    <p><?php echo e(trans('home.message.md')); ?></p>
                </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="panel panel-primary animated fadeInUp animation-delay-12">
                  <div class="panel-heading localefont"><?php echo e(trans('app.itc')); ?></div>
                  <div class="panel-body">
                    
                    <div class="col-md-12">
                      <div id="carousel-example-captions" class="carousel carousel-images slide" data-ride="carousel"  data-interval="5000">
                                <section class="animated fadeInDown animation-delay-4">
                                   
                                    <div class="carousel-inner">
                                        <div class="item active">
                                        <img src="img/others/ak.jpg" alt="First slide image">
                                        </div>
                                        <div class="item ">
                                        <img src="img/others/cambodia.jpg" alt="Second slide image">
                                        </div>
                                        <div class="item">
                                        <img src="img/others/im.jpg" alt="Third slide image">
                                        </div>
                                    </div>
                                    
                                </section>
                      </div>
                    </div>
                    <p class="p-style"><?php echo e(trans('app.itc.content')); ?></p>
                    <p><?php echo e(trans('training.cmb.header2')); ?></p>
                    <ul class="li-style">
                      <li><b><?php echo e(trans('training.cmb.header4')); ?></b><?php echo e(trans('training.cmb.content1')); ?></li>
                      <li><b><?php echo e(trans('training.cmb.header5')); ?></b><?php echo e(trans('training.cmb.content2')); ?></li>
                      <li><b><?php echo e(trans('training.cmb.header3')); ?></b><?php echo e(trans('training.cmb.content3')); ?></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </article> <!-- post -->
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>