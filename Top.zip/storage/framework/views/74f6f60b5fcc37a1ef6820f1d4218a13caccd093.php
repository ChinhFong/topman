<div class="sb-site-container">
<div class="boxed">
<header id="header-full-top" class="hidden-xs header-full">
    <div class="container">
        <div class="header-full-title">
            <a href="/" style="text-decoration:none;">
            <img class="logo-style" src="img/icon-flag/topuse.png"></a>
        </div>
        <nav class="top-nav lang-z">
            <ul class="top-nav-social hidden-sm animated fadeInDown animation-delay-12" style="width:250px;">
                <?php echo Form::open(['url'=>'/SwitchLan','method'=>'post','class'=>'lang']); ?>

                <p class="animated fadeIn animation-delay-6 localefont lang-style"><?php echo e(trans('app.language')); ?>:</p>
                  <?php
                    $lo="";
                    if(App::getLocale() == 'en'){$lo="en";}else if(App::getLocale() == 'th'){$lo="th";}
                    else if(App::getLocale()=="ch"){$lo="ch";}else{ $lo="kh";}
                  ?>
                  <button id="dLabel" class="languages" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img class="image-font">
                  <?php echo e(trans('app.'.$lo)); ?>

                  <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu dropdown-hover" style="left:105px;" aria-labelledby="dLabel">
                    <li class="kh" ><img src="img/icon-flag/khmer.png"><?php echo e(trans('app.kh')); ?> </li>
                    <li class="en"><img src="img/icon-flag/english.png"><?php echo e(trans('app.en')); ?></li>
                    <li class="th"><img src="img/icon-flag/thai_flag.png"><?php echo e(trans('app.th')); ?></li>
                    <li class="ch"><img src="img/icon-flag/chinese.png"><?php echo e(trans('app.ch')); ?></li>
                  </ul>
                
                  <?php echo e(csrf_field()); ?>


                <?php echo Form::hidden('locale',$lo,['id'=>'locale']); ?>

                <?php echo Form::close(); ?>

            </ul>
            <div class="dropdown animated fadeInDown animation-delay-16 localefont">
                <a href="https://www.facebook.com/manpower.com.kh/" target="_blank" class="animated fadeIn animation-delay-7 facebook"><i class="fa fa-facebook"></i></a>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-search"></i></a>
                <div class="dropdown-menu dropdown-menu-right dropdown-search-box animated fadeInUp">
                    <form role="form">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-ar btn-primary" type="button">Go!</button>
                            </span>
                        </div><!-- /input-group -->
                    </form>
                </div>
            </div>

            

           <!-- dropdown -->
        </nav>
        <nav class="top-nav top-nav-padding">
          <div class="dropdown animated fadeInDown animation-delay-13">
                <?php if(Auth::guest()): ?>
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                


                </button>
                </form>
                





                <?php else: ?>
                    <ul class="nav navbar-nav navbar-right">
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu">
                          <li>
                            <a href="<?php echo e(url('/logout')); ?>"
                                    onclick="event.preventDefault();document.getElementById('logout-form').submit();" ><i class="fa fa-sign-out "></i> <?php echo e(trans('app.signout')); ?></a>
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                          </li>
                        </ul>
                      </li>
                    </ul>
                <?php endif; ?>
            </div>

    </nav>
    </div> <!-- container -->
</header> <!-- header-full -->
<nav class="navbar navbar-default navbar-header-full navbar-dark yamm navbar-static-top" role="navigation" id="header">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <i class="fa fa-bars"></i>
            </button>
            <a id="ar-brand" class="navbar-brand hidden-lg hidden-md hidden-sm localefont" href="/"><?php echo e(trans('app.tmp')); ?></a>
        </div> <!-- navbar-header -->

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="pull-right hidden-lg hidden-md">
            <a href="javascript:void(0);" class="sb-icon-navbar sb-toggle-right"><i class="fa fa-bars"></i></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li id="home"><a class="localefont"  href="/"><?php echo e(trans('app.home')); ?></a></li>
                <li id="aboutus" class="dropdown">
                    <a  href="javascript:void(0);" class="dropdown-toggle localefont" data-toggle="dropdown" data-hover="dropdown"><?php echo e(trans('app.aboutus')); ?></a>
                     <ul class="dropdown-menu dropdown-menu-left animated-2x animated fadeIn">
                        <li ><a class="localefont" href="/profile"><?php echo e(trans('app.profile')); ?></a></li>
                        <li><a class="localefont" href="/management"><?php echo e(trans('app.management')); ?></a></li>
                        <li><a class="localefont" href="/strategy"><?php echo e(trans('app.strategy')); ?></a></li>
                        <li><a class="localefont" href="/license"><?php echo e(trans('app.license')); ?></a></li>
                    </ul>
                </li>
                <li id="services"><a class="localefont" href="/services"><?php echo e(trans('app.services')); ?></a></li>
                
                <li id="training"><a class="localefont" href="/training"><?php echo e(trans('app.training')); ?></a></li>
                <li id="progress"><a class="localefont" href="/processing"><?php echo e(trans('app.processing')); ?></a></li>

                <li id="faq"><a class="localefont" href="/faq"><?php echo e(trans('app.faq')); ?></a></li>
                <li id="photo"><a class="localefont" href="/gallery"><?php echo e(trans('app.gallery')); ?></a></li>
                <li id="contact"><a class="localefont" href="/contact"><?php echo e(trans('app.contact')); ?></a></li>
             </ul>
        </div><!-- navbar-collapse -->
    </div><!-- container -->
</nav>
<?php echo $__env->yieldContent('content'); ?>
</div>
</div>
