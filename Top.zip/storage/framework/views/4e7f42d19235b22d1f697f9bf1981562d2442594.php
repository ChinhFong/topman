<?php $__env->startSection('title','training'); ?>
<?php $__env->startSection('content'); ?>
<header class="main-header">
    <div class="container">
        <h1 class="page-title">&nbsp;</h1>
        <ol class="breadcrumb pull-right localefont">
            <li><a href="#"><?php echo e(trans('app.pages')); ?></a></li>
            <li class="active"><?php echo e(trans('app.training')); ?></li>
        </ol>
    </div>
</header>
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <h1 class="right-line no-margin-top localefont" style="overflow: visible;" ><?php echo e(trans('app.training')); ?></h1>
        </div>
        <div class="col-md-12" style="padding: 5px 0px;">
        <div id="carousel-example-captions" class="carousel carousel-images slide" data-ride="carousel"  data-interval="5000">
                  <section class="animated fadeInDown animation-delay-4">
                     
                      <div class="carousel-inner slide-style" >
                          <div class="item active">
                          <img src="img/others/train_use_1.jpg" alt="First slide image">
                          </div>
                          <div class="item ">
                          <img src="img/others/train_use_2.jpg" alt="Second slide image">
                          </div>
                          <div class="item">
                          <img src="img/others/train_use_3.jpg" alt="Third slide image">
                          </div>
                      </div>
                      
                  </section>
        </div>
      </div>
        
        <div class="col-md-12">
          <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <p class="p-style"><?php echo e(trans('training.header')); ?></p>
          </section>
        </div>
        <div class="col-md-12">
          <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <h4><?php echo e(trans('training.infra')); ?></h4>
            <p><?php echo e(trans('training.infra.content')); ?></p>
          </section>
        </div>
        <div class="col-md-12">
          <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <h4><?php echo e(trans('training.dura')); ?></h4>
            <ul class="train">
                <li><?php echo e(trans('training.dura.content1')); ?></li>
                <li><?php echo e(trans('training.dura.content2')); ?></li>
                <li><?php echo e(trans('training.dura.content3')); ?></li>
            </ul>
          </section>
        </div>
        <div class="col-md-12">
          <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <h4><?php echo e(trans('training.cir')); ?></h4>
            <p><?php echo e(trans('training.cir.header')); ?></p>
            <ul class="train">
                <li><?php echo e(trans('training.cir.content1')); ?></li>
                <li><?php echo e(trans('training.cir.content2')); ?></li>
                <li><?php echo e(trans('training.cir.content3')); ?></li>
                <li><?php echo e(trans('training.cir.content4')); ?></li>
                <li><?php echo e(trans('training.cir.content5')); ?></li>
            </ul>
          </section>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>