<?php $__env->startSection('title'); ?>
	<?php echo e(trans('app.services')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="main-header">
    <div class="container">
        <h1 class="page-title">&nbsp;</h1>
        <ol class="breadcrumb pull-right localefont">
            <li><a href="#"><?php echo e(trans('app.pages')); ?></a></li>
            <li class="active"><?php echo e(trans('app.services')); ?></li>
        </ol>
    </div>
</header>
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <h1 class="right-line no-margin-top localefont" style="overflow: visible;" ><?php echo e(trans('app.services')); ?></h1>
        </div>
        <div class="col-md-8 localefont">
          <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <h4 class="localefont"><?php echo e(trans('services.content')); ?></h4>
          </section>
          
          <ul class="fa-ul">
           <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <li><h4 class="localefont"><img class="flag-img" src="img/icon-flag/thai.png"></i> <?php echo e(trans('services.thai')); ?></h4>
              <ul class="style">
                <li><?php echo e(trans('services.thai1')); ?></li>
                <li><?php echo e(trans('services.thai2')); ?></li>
                <li><?php echo e(trans('services.thai3')); ?></li>
                <li><?php echo e(trans('services.thai4')); ?></li>
              </ul>
            </li>
            </section>
            <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
               <li><h4 class="localefont"><img class="flag-img" src="img/icon-flag/japan.png"><?php echo e(trans('services.japan')); ?></h4>
                 <ul class="style">
                  <li><?php echo e(trans('services.japan1')); ?></li>
									<li><?php echo e(trans('services.japan2')); ?></li>
                </ul>
              </li>
            </section>
            <section class="animated wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
               <li style="overflow:visible;"><h4 class="localefont font-khmer" > <img class="flag-img" src="img/icon-flag/malay.png"><?php echo e(trans('services.malay')); ?> <img class="flag-img" src="img/icon-flag/brunei.png"><?php echo e(trans('services.brunei')); ?> <img class="flag-img" src="img/icon-flag/hongkong.png"> <?php echo e(trans('services.hk')); ?> <img class="flag-img" src="img/icon-flag/macau.png"> <?php echo e(trans('services.ma')); ?> <img class="flag-img" src="img/icon-flag/singapore.png"> <?php echo e(trans('services.sing')); ?></h4>
                 <ul class="style">
                  <li><?php echo e(trans('services.mbshm1')); ?></li>
                  <li><?php echo e(trans('services.mbshm2')); ?></li>
                </ul>
              </li>
            </section>
          </ul>
        </div>
        <div class="col-md-4">
          <div class="row">
              <div class="col-md-12" style="padding: 5px 0px;">
              <div id="carousel-example-captions" class="carousel carousel-images slide" data-ride="carousel"  data-interval="5000">
                        <section class="animated fadeInDown animation-delay-4">
                           <ol class="carousel-indicators">
                                <li data-target="#carousel-example-captions" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-captions" data-slide-to="1" class=""></li>
                                <li data-target="#carousel-example-captions" data-slide-to="2" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item active">
                                <img src="img/service2.png" alt="First slide image">
                                <div class="carousel-caption animated fadeInUpBig">
                                    <h3 class=""><?php echo e(trans('services.learn')); ?></h3>
                                    <p><?php echo e(trans('services.learn.language')); ?></p>
                                </div>
                                </div>
                                <div class="item ">
                                <img src="img/service3.jpg" alt="Second slide image">
                                <div class="carousel-caption animated fadeInUpBig">
                                    <h3><?php echo e(trans('services.worker')); ?></h3>
                                    <p><?php echo e(trans('services.worker.activities')); ?></p>
                                </div>
                                </div>
                                <div class="item">
                                <img src="img/service5.jpg" alt="Third slide image">
                                <div class="carousel-caption animated fadeInUpBig">
                                    <h3><?php echo e(trans('services.worker')); ?></h3>
                                    <p><?php echo e(trans('services.worker.activities')); ?></p>
                                </div>
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-captions" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-captions" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </section>
              </div>
            </div>
            <div class="col-md-12" style="padding: 5px 0px;">
              <div id="carousel-example-captions2" class="carousel carousel-images slide" data-ride="carousel" data-interval="6000">
                        <section class="animated fadeInDown animation-delay-7">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-captions2" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-captions2" data-slide-to="1" class=""></li>
                                <li data-target="#carousel-example-captions2" data-slide-to="2" class=""></li>
                            </ol>
                            <div class="carousel-inner localefont">
                                <div class="item active">
                                <img src="img/DSC_3.jpg" alt="First slide image">
                                <div class="carousel-caption animated fadeInUpBig ">
                                    <h3 class="localefont"><?php echo e(trans('services.maid')); ?></h3>
                                    <p style="text-align: center;"><?php echo e(trans('services.maidtrain')); ?></p>
                                </div>
                                </div>
                                <div class="item ">
                                <img src="img/DSC_2.jpg" alt="Second slide image">
                                <div class="carousel-caption animated fadeInUpBig">
                                    <h3 class="localefont"><?php echo e(trans('services.maid')); ?></h3>
                                    <p style="text-align: center;"><?php echo e(trans('services.maidtrain')); ?></p>
                                </div>
                                </div>
                                <div class="item">
                                <img src="img/DSC_1.jpg" alt="Third slide image">
                                <div class="carousel-caption animated fadeInUpBig">
                                    <h3 class="localefont"><?php echo e(trans('services.maid')); ?></h3>
                                    <p style="text-align: center;"><?php echo e(trans('services.maidtrain')); ?></p>
                                </div>
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-captions2" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-captions2" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </section>
              </div>
            </div>
          </div>
        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>