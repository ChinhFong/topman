<?php 
return [
'rm1'	=>	'To contribute in creating overseas labor markets',
'content'	=>  'To contribute in creating overseas labor markets by supplying efficient and well-qualified manpower to clients and providing a better job opportunities for Cambodian migrant workers and trainees.',
];