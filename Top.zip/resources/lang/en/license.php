<?php 
return[
	'coi'=>'Certificate Of Incorporation',
	'bru'=>'Brunei',
	'th'=>'Thailand',
	'hkm'=>'Hong Kong & Macau',
	'ja'=>'Japan',
	'mal'=>'Malaysia',
	'sin'=>'Singapore',
];