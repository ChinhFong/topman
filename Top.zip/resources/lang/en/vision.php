<?php 
return [
'rm1'	=>	'To become as one of the leading recruitment',
'content'	=>	'To become as one of the leading recruitment agencies in term of effectiveness, qualities, social responsible and honest business principles.',
];