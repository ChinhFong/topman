<!-- Button trigger modal -->
<!-- Modal1 -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{trans('home.maidtrain')}}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_1.jpg" alt="" class="img-responsive">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal2 -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{trans('home.maidtrain')}}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_2.jpg" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal3 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{trans('home.maidtrain')}}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_3.jpg" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal4 -->
<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{trans('home.maidtrain')}}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_4.jpg" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal5 -->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">{{trans('home.maidtrain')}}</h4>
            </div>
            <div class="modal-body">
                <img src="img/DSC_5.jpg" class="img-responsive" alt="Image">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal6 -->
<div class="modal fade" id="myModal6" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{trans('home.maidtrain')}}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_6.jpg" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal7 -->
