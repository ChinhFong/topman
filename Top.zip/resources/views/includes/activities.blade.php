<div class="modal fade" id="myModal7" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_9.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal8 -->
<div class="modal fade" id="myModal8" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_10.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>

<!-- Modal9 -->
<div class="modal fade" id="myModal9" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_11.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal10 -->
<div class="modal fade" id="myModal10" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_13.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal11 -->
<div class="modal fade" id="myModal11" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_14.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal12 -->
<div class="modal fade" id="myModal12" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_15.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal13 -->
<div class="modal fade" id="myModal13" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_16.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal14 -->
<div class="modal fade" id="myModal14" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_4.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal15 -->
<div class="modal fade" id="myModal15" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_28.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal15 -->
<div class="modal fade" id="myModal16" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_12.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal15 -->
<div class="modal fade" id="myModal17" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_19.jpg" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal15 -->
<div class="modal fade" id="myModal18" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_20.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal15 -->
<div class="modal fade" id="myModal19" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_24.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal15 -->
<div class="modal fade" id="myModal20" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_25.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<!-- Modal15 -->
<div class="modal fade" id="myModal21" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_29.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<div class="modal fade" id="myModal22" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg  ">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/DSC_12.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<div class="modal fade" id="myModal23" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg  ">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/others/train_2.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
<div class="modal fade" id="myModal24" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg  ">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">{{ trans('app.activities') }}</h4>
        </div>
        <div class="modal-body">
            <img src="img/others/train_1.JPG" class="img-responsive" alt="Image">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ar btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>
