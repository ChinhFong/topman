<?php $__env->startSection('title'); ?>
<?php echo e(trans('app.strategy')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="main-header">
<div class="container">
    <h1 class="page-title">&nbsp;</h1>
    <ol class="breadcrumb pull-right localefont">
        <li><a href="#"><?php echo e(trans('app.pages')); ?></a></li>
        <li  class="active"><?php echo e(trans('app.aboutus')); ?></li>
        <li class="active"><?php echo e(trans('app.strategy')); ?></li>
    </ol>
</div>
</header>
<div class="container">
<div class="row">
  <div class="col-xs-12">
      <h1 class="right-line no-margin-top" style="overflow: visible;" ><?php echo e(trans('app.strategy')); ?></h1>
      <h2 class="slogan animated bounceInLeft animation-delay-12​​ localefont"><?php echo e(trans('strategy.header')); ?>

      </h2>
  </div>
  <div class="col-xs-12">
      <article class="acticle-style">
        <div class="panel panel-default">
          <div class="panel-body">
            <h3 class="post-title post-title-strategy"><i class="fa fa-star" style="margin-right: 5px;"></i><?php echo e(trans('home.sustainability')); ?></h3>
            <div class="row">
                <div class="col-md-12">
                <section class="animated wow fadeInUp">
                  <div class="strate">
                    <p class="p-lg"><?php echo e(trans('strategy.sus.content')); ?></p>
                    </div>
                </section>
                </div>
            </div>
          </div>
          <div class="panel-body">
            <h3 class="post-title post-title-strategy"><i class="fa fa-star" style="margin-right: 5px;"></i><?php echo e(trans('app.services')); ?></h3>
            <div class="row">
                <div class="col-md-12">
                <section class="animated wow fadeInUp localefont" style="visibility: visible; animation-name: fadeInUp;">
                  <div class="strate">
                     <p class="p-lg"><?php echo e(trans('strategy.service.content')); ?></p>
                  </div>
                </section>
                </div>
            </div>
          </div>
          <div class="panel-body">
            <h3 class="post-title post-title-strategy"><i class="fa fa-star" style="margin-right: 5px;"></i><?php echo e(trans('home.socialresponsibility')); ?></h3>
            <div class="row">
                <div class="col-md-12">
                <section class="animated wow fadeInUp localefont" style="visibility: visible; animation-name: fadeInUp;">
                  <div class="strate">
                    <p class="p-lg"><?php echo e(trans('strategy.sr.content')); ?></p>
                  </div>
                </section>
                </div>
            </div>
          </div>
  </div>
  
  </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>