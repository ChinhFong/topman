<?php $__env->startSection('title'); ?>
	<?php echo e(trans('app.license')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="main-header">
    <div class="container">
        <h1 class="page-title">&nbsp;</h1>
        <ol class="breadcrumb pull-right localefont">
            <li><a href="#"><?php echo e(trans('app.pages')); ?></a></li>
            <li class="active"><?php echo e(trans('app.aboutus')); ?></li>
            <li class="active"><?php echo e(trans('app.license')); ?></li>
        </ol>
    </div>
</header>
<div class="container">
  <div class="row">
    <div class="col-xs-12">
        <h1 class="right-line no-margin-top localefont" style="overflow: visible;" ><?php echo e(trans('app.license')); ?></h1>
    </div>
  	<div class="col-md-12">
    <!-- Nav tabs -->
    <ul class="nav nav-tabs nav-tabs-round">
    <li class="active"><a href="#coi" data-toggle="tab"><?php echo e(trans('license.coi')); ?></a></li>
    <li><a href="#fbru" data-toggle="tab"> <img class="flag-img" src="img/icon-flag/brunei.png"> <?php echo e(trans('license.bru')); ?></a></li>
    <li><a href="#fth" data-toggle="tab"><img class="flag-img" src="img/icon-flag/thai.png"><?php echo e(trans('license.th')); ?></a></li>
    <li><a href="#fhkm" data-toggle="tab"><img class="flag-img" src="img/icon-flag/hongkong.png"><img class="flag-img" src="img/icon-flag/macau.png"><?php echo e(trans('license.hkm')); ?></a></li>
    <li><a href="#fja" data-toggle="tab"><img class="flag-img" src="img/icon-flag/japan.png"><?php echo e(trans('license.ja')); ?></a></li>
    <li><a href="#fmal" data-toggle="tab"><img class="flag-img" src="img/icon-flag/malay.png"><?php echo e(trans('license.mal')); ?></a></li>
    <li><a href="#fsin" data-toggle="tab"><img class="flag-img" src="img/icon-flag/singapore.png"><?php echo e(trans('license.sin')); ?></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content tab-margin tab-content-margin">
      <div class="tab-pane active" id="coi">
        <img src="img/license_images/coi.jpg" class="img-responsive imageborder img-center">
      </div>
      <div class="tab-pane" id="fbru">
         <img src="img/license_images/brunei.jpg" class="img-responsive img-center">
      </div>
      <div class="tab-pane" id="fth">
         <img src="img/license_images/thai.jpg" class="img-responsive img-center">
      </div>
       <div class="tab-pane" id="fhkm">
         <img src="img/license_images/hkm.jpg" class="img-responsive img-center">
      </div>
      <div class="tab-pane" id="fja">
         <img src="img/license_images/japan.jpg" class="img-responsive img-center">
      </div>
      <div class="tab-pane" id="fmal">
         <img src="img/license_images/malaysia.jpg" class="img-responsive img-center">
      </div>
      <div class="tab-pane" id="fsin">
         <img src="img/license_images/singapore.jpg" class="img-responsive img-center">
      </div>
    </div>
    </div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>