<?php $__env->startSection('title'); ?>
	<?php echo e(trans('app.management')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="main-header">
    <div class="container">
        <h1 class="page-title">&nbsp;</h1>
        <ol class="breadcrumb pull-right localefont">
            <li><a href="#"><?php echo e(trans('app.pages')); ?></a></li>
            <li class="active"><?php echo e(trans('app.aboutus')); ?></li>
            <li class="active"><?php echo e(trans('app.management')); ?></li>
        </ol>
    </div>
</header>
<div class="container">
    <div class="row">
    <div class="">
            <h1 class="right-line no-margin-top localefont" style="overflow: visible;" ><?php echo e(trans('app.management')); ?></h1>
    </div>
    <div class="container">
    <div class="row">
        <section class="animated text-icon wow fadeInDown animation-delay-2 localefont" style="visibility: visible; animation-name: fadeInDown;">
            <div class="col-sm-6 col-md-2 col-md-offset-1">
                <img class="management-profile-style" src="img/management/bbath.jpg">
                <h4 class="panel-header localefont management-style"><?php echo e(trans('management.md')); ?></h4>
            </div>
        <div class="col-sm-6 col-md-8">
            <h3 class="localefont"><?php echo e(trans('management.md.name')); ?></h3>
            <!-- Nav tabs -->
            
						<p><?php echo e(trans('management.md.background')); ?></p>
        </div>
        </section>
				<hr style="width: 60%; text-align: center; margin: 0 auto;">
        <section class="animated text-icon wow fadeInDown animation-delay-2 localefont" style="visibility: visible; animation-name: fadeInDown;">
            <div class="col-sm-6 col-md-2 col-md-offset-1">
                <img class="management-profile-style" src="img/management/bkhemera.jpg">
                <h4 class="panel-header localefont management-style"><?php echo e(trans('management.ad')); ?></h4>
            </div>
            <div class="col-sm-6 col-md-8">
                <h3 class="localefont"><?php echo e(trans('management.ad.name')); ?></h3>
                <!-- Nav tabs -->
                
								<p><?php echo e(trans('management.ad.background')); ?></p>
            </div>
        </section>
				<hr style="width: 60%; text-align: center; margin: 0 auto;">
        <section class="animated text-icon wow fadeInDown animation-delay-2 localefont" style="visibility: visible; animation-name: fadeInDown;">
            <div class="col-sm-6 col-md-2 col-md-offset-1">
                <img class="management-profile-style img-responsive " src="img/management/bdara.jpg">
                <h4 class="panel-header localefont management-style" ><?php echo e(trans('management.hrm')); ?></h4>
            </div>
            <div class="col-sm-6 col-md-8">
                <h3 class="localefont"><?php echo e(trans('management.hrm.name')); ?></h3>
                
								<p><?php echo e(trans('management.hrm.background')); ?></p>
            </div>
        </section>
				<hr style="width: 60%; text-align: center; margin: 0 auto;">
        <section class="animated text-icon wow fadeInDown animation-delay-2 localefont" style="visibility: visible; animation-name: fadeInDown;">
            <div class="col-sm-6 col-md-2 col-md-offset-1">
                <img class="management-profile-style" src="img/management/bya.jpg">
                <h4 class="panel-header localefont management-style" ><?php echo e(trans('management.fd')); ?></h4>
            </div>
        <div class="col-sm-6 col-md-8">
            <h3 class="localefont"><?php echo e(trans('management.fd.name')); ?></h3>
            
						<p><?php echo e(trans('management.fd.background')); ?></p>
            </div>
        </div>
        </section>
				<hr style="width: 60%; text-align: center; margin: 0 auto;">
        <section class="animated text-icon wow fadeInDown animation-delay-2 localefont" style="visibility: visible; animation-name: fadeInDown;">
            <div class="col-sm-6 col-md-2 col-md-offset-1">
                <img class="management-profile-style" src="img/management/bdarady.jpg">
                <h4 class="panel-header localefont management-style"><?php echo e(trans('management.mkd')); ?> </h4>
            </div>
            <div class="col-sm-6 col-md-8">
                <h3 class="localefont"><?php echo e(trans('management.mkd.name')); ?></h3>
                <!-- Nav tabs -->
                
                
                
                
                
								<p><?php echo e(trans('management.mkd.background')); ?></p>
            </div>
        </section>
				<hr style="width: 60%; text-align: center; margin: 0 auto;">
        <section class="animated text-icon wow fadeInDown animation-delay-2 localefont" style="visibility: visible; animation-name: fadeInDown;">
            <div class="col-sm-6 col-md-2 col-md-offset-1">
                <img class="management-profile-style" src="img/management/bpheap.jpg">
                <h4 class="panel-header localefont  management-style"><?php echo e(trans('management.td')); ?></h4>
            </div>
            <div class="col-sm-6 col-md-8">
                <h3 class="localefont"><?php echo e(trans('management.td.name')); ?></h3>
                
								<p><?php echo e(trans('management.td.background')); ?></p>
            </div>
        </section>
    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>