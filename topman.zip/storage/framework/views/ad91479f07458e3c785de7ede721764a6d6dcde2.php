<?php $__env->startSection('title'); ?>
	<?php echo e(trans('app.aboutus')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<header class="main-header">
    <div class="container">
        <h1 class="page-title">&nbsp;</h1>
        <ol class="breadcrumb pull-right localefont">
            <li><a href="#"><?php echo e(trans('app.pages')); ?></a></li>
            <li class="active"><?php echo e(trans('app.aboutus')); ?></li>
            <li class="active"><?php echo e(trans('app.profile')); ?></li>
        </ol>
    </div>
</header>
<div class="container">
    <div class="row">
        <div class="col-xs-12">

            <h1 class="right-line no-margin-top localefont" style="overflow: visible;" ><?php echo e(trans('app.profile')); ?></h1>
        </div>
        <div class="col-md-8 localefont">
            <section class="animated fadeInDown animation-delay-8">
                <img src="img/aboutus.jpg" class="img-responsive imageborder" alt="Image">
                <p class="p-lg"><strong><?php echo e(trans('app.tmp')); ?></strong><?php echo e(trans('aboutus.content')); ?></p>
                <p class="p-lg"><?php echo e(trans('aboutus.content2')); ?></p>
                <p class="p-lg"><?php echo e(trans('aboutus.content3')); ?></p>
                <img src="img/aboutus2.jpg" class="img-responsive imageborder" alt="Image">
            </section>
        </div>
        <div class="col-md-4">
            <div class="panel panel-primary animated fadeInUp animation-delay-12">
                <div class="panel-heading localefont"><?php echo e(trans('app.aboutus')); ?></div>
                <div class="panel-body">
                    <section>
                        <h4 class="copy-second-title localefont"><?php echo e(trans('app.vision')); ?></h4>
                        <img src="img/vision.jpg">
                        <p class="p-lg p-style"><strong><?php echo e(trans('app.tmp')); ?></strong> <?php echo e(trans('home.vision')); ?></p>
                    </section>
                    <section>
                        <h4 class="copy-second-title localefont"><?php echo e(trans('app.mission')); ?></h4>
                        <img src="img/mission.jpg" class="">
                        <p class="p-lg p-style"><strong><?php echo e(trans('app.tmp')); ?></strong> <?php echo e(trans('home.mission')); ?></p>

                    
                    </section>
                </div>
            </div>
        </div>
    </div>
</div> <!-- container -->

    </div> 
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>