<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Mail</title>
</head>
<body>
<p>
Name: {{ $name }}
</p>

<p>
Email: {{ $email }}
</p>

<p>
User_Message: {{ $user_message }}
</p>
</body>
</html>