Welcome, {{ $name }}
Please verify your account : {{ url('user/verify',$link)}}