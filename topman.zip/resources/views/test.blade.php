<?php
echo '<script type="text/javascript">
           window.location = "http://www.google.com/"
      </script>';
?>
{{-- @extends('layouts.app')
@section('title')
	{{ trans('aboutus.aboutus') }}
@stop
@section('content')
<header class="main-header">
    <div class="container">
        <h1 class="page-title">&nbsp;</h1>
        <ol class="breadcrumb pull-right localefont">
            <li><a href="#">{{ trans('app.pages')}}</a></li>
            <li class="active">{{ trans('app.aboutus')}}</li>
            <li class="active">{{ trans('app.profile')}}</li>
        </ol>
    </div>
</header>
<div class="row">
	<div class="col-md-2 col-xs-2">
	 <div class="dropdown">
		  <button id="dLabel" class="languages" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		    Dropdown trigger
		    <span class="caret"></span>
		  </button>
		  <ul class="dropdown-menu dropdown-hover" aria-labelledby="dLabel">
		    <li><img src="img/khmer.png">{{ trans('app.kh') }} </li>
		    <li><img src="img/english.png"> {{ trans('app.en') }}</li>
		  </ul>
		</div>
	</div>
</div>

@stop --}}
