<html>
<head>
  <meta property="og:url"           content="https://www.your-domain.com/your-page.html" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="Your Website Title" />
    <meta property="og:description"   content="Your description" />
    <meta property="og:image"         content="img\DSC_16.jpg" />
</head>
<body>

<iframe id="fbs" src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Ftopman.com.kh%2Fnews&layout=button_count&size=small&mobile_iframe=true&width=69&height=20&appId" width="69" height="20" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe></body>

</body>
</html>
