<div id="carousel-example-captions" class="carousel carousel-images slide" data-ride="carousel"  data-interval="5000">
          <section class="animated fadeInDown animation-delay-4">
             <ol class="carousel-indicators">
                  <li data-target="#carousel-example-captions" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-example-captions" data-slide-to="1" class=""></li>
                  {{-- <li data-target="#carousel-example-captions" data-slide-to="2" class=""></li> --}}
              </ol>
              <div class="carousel-inner slide-style" >
                  {{-- <div class="item active">
                  <img src="img/others/train_use_1.jpg" class="img-responsive " alt="First slide image">
                  </div> --}}
                  <div class="item active">
                  <img src="img/others/top_slide_3.jpg" class="img-responsive " alt="Second slide image">
                  </div>
                  <div class="item">
                  <img src="img/others/top_slide_4.jpg" class="img-responsive " alt="Third slide image">
                  </div>
                  {{-- <div class="item">
                  <img src="img/others/top_slide_4.jpg" class="img-responsive imageborder" alt="Forth slide image">
                  </div>
                  <div class="item">
                  <img src="img/others/train_use_3.jpg" class="img-responsive imageborder" alt="Fifth slide image">
                  </div>
                  <div class="item">
                  <img src="img/others/train_use_3.jpg" class="img-responsive imageborder" alt="Sixth slide image">
                  </div> --}}
              </div>
              <a class="left carousel-control" href="#carousel-example-captions" data-slide="prev">
                  <span class="glyphicon glyphicon-chevron-left"></span>
              </a>
              <a class="right carousel-control" href="#carousel-example-captions" data-slide="next">
                  <span class="glyphicon glyphicon-chevron-right"></span>
              </a>
          </section>
</div>
