<?php
return [
'rm1'	=>	'To contribute in creating overseas labor markets',
'content'	=>  '日本でもっとも優秀な人材を、多く受け入れる為、またカンボジアでは優秀な人材を教育訓練をし派遣出来るようお互いに協力努力して参りたいと願います。
',
];
