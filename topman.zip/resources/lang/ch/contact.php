<?php
return[
'additional'	=>	'额外信息',
];
