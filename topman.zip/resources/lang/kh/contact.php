<?php 
return[
'additional'	=>	'ព័ត៍មានបន្ថែម',
];